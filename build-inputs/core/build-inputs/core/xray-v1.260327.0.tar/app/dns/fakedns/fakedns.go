package fakedns
